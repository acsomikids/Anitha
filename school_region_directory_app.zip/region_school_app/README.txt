SCHOOL REGION DIRECTORY — DEPLOYMENT GUIDE

What this app does
- Lets users select a region (Rotn, Ntn, Kl, Tel, etc.)
- Filters school records and searches across columns
- Lets users download the filtered results as CSV
- Includes optional AI question answering when an OpenAI API key is configured

HOW TO GET A PUBLIC LINK
1. Sign in to GitHub and create a new repository, for example: school-region-directory.
2. Upload these three files to the repository root: app.py, data.xlsx, requirements.txt.
3. Sign in to https://share.streamlit.io/ (Streamlit Community Cloud) using GitHub.
4. Choose “Create app”, select your repository and the app.py file, then deploy.
5. Streamlit will provide a public URL you can share with your team.

OPTIONAL AI SETUP
1. Create an OpenAI API key in your OpenAI developer account.
2. In Streamlit app settings, open Secrets and add:
   OPENAI_API_KEY = "your-api-key-here"
3. Save/reboot the app. Do not put your API key in app.py or upload it to GitHub.

IMPORTANT
- A live public link cannot be generated until the app is deployed from an account with hosting access.
- Anyone with the public link may be able to view school addresses and contact numbers. Check that the workbook is approved for sharing before deployment.
- To keep the app updated, replace data.xlsx in the GitHub repository and redeploy/reboot the app.
