import os
import pandas as pd
import streamlit as st

st.set_page_config(page_title="School Region Directory", page_icon="🏫", layout="wide")

st.title("🏫 School Region Directory")
st.caption("Choose a region to view its school details. Use the search box to narrow the results.")

DATA_FILE = os.path.join(os.path.dirname(__file__), "data.xlsx")

@st.cache_data
def load_data():
    df = pd.read_excel(DATA_FILE)
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")]
    if "Region" not in df.columns:
        raise ValueError("The Excel file must contain a 'Region' column.")
    df["Region"] = df["Region"].fillna("").astype(str).str.strip()
    return df

try:
    df = load_data()
except Exception as exc:
    st.error(f"Could not load data.xlsx: {exc}")
    st.stop()

regions = sorted([r for r in df["Region"].unique().tolist() if r])
col1, col2 = st.columns([1, 2])
with col1:
    selected_region = st.selectbox("Select region", ["All regions"] + regions)
with col2:
    search = st.text_input("Search school, area, trainer, or contact", placeholder="Type a name, place, or phone number")

filtered = df.copy()
if selected_region != "All regions":
    filtered = filtered[filtered["Region"] == selected_region]
if search.strip():
    mask = filtered.astype(str).apply(lambda col: col.str.contains(search.strip(), case=False, na=False)).any(axis=1)
    filtered = filtered[mask]

st.metric("Schools found", len(filtered))
# Show the most useful columns first while retaining other available fields.
preferred = ["Region", "Name of the school", "Area", "Address", "Trainer Name", "Bdaah/Ah", "Year"]
ordered = [c for c in preferred if c in filtered.columns] + [c for c in filtered.columns if c not in preferred]
st.dataframe(filtered[ordered], use_container_width=True, hide_index=True)

csv = filtered.to_csv(index=False).encode("utf-8-sig")
st.download_button("Download selected results as CSV", data=csv, file_name="school_region_results.csv", mime="text/csv")

st.divider()
st.subheader("Ask AI about this region (optional)")
st.caption("To enable AI, add an OpenAI API key as a Streamlit secret named OPENAI_API_KEY. Without a key, the region filter and search still work.")
question = st.text_input("Ask a question about the currently filtered schools", placeholder="Example: How many schools are in this area?")
if st.button("Ask AI", disabled=not question.strip()):
    api_key = None
    try:
        api_key = st.secrets.get("OPENAI_API_KEY")
    except Exception:
        api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        st.warning("AI is not enabled yet. Add OPENAI_API_KEY in the app's Streamlit secrets settings.")
    else:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            context = filtered.fillna("").to_csv(index=False)
            response = client.responses.create(
                model="gpt-4.1-mini",
                instructions=("Answer questions using only the school data provided. Be concise. "
                              "If the answer is not in the data, say so. Do not infer missing details."),
                input=f"Selected region: {selected_region}\nSchool data (CSV):\n{context[:45000]}\n\nQuestion: {question}"
            )
            st.write(response.output_text)
        except Exception as exc:
            st.error(f"AI request failed: {exc}")

st.caption("Access note: anyone with the public app link may be able to view the school contact details in this workbook. Only publish it if that is appropriate for your team.")
